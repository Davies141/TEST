

import java.util.ArrayList;
import java.util.List;

public class Library {
    private List<LibraryItem> items;

    public Library() {
        items = new ArrayList<>();
    }

    public void addItem(LibraryItem item) {
        items.add(item);
    }

    public boolean removeItem(String title) {
        return items.removeIf(item -> item.getDetails().contains(title));
    }

    public LibraryItem findItemByTitle(String title) {
        for (LibraryItem item : items) {
            if (item.getDetails().contains(title)) {
                return item;
            }
        }
        return null;
    }

    public List<LibraryItem> listItems() {
        return items;
    }

    public List<LibraryItem> getItems() {
        return items;
    }

    public void setItems(List<LibraryItem> items) {
        this.items = items;
    }

}
