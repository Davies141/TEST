import java.util.Scanner;

public class LibraryApp {

    private static final Library library = new Library(); // Library instance
    private static final Scanner scanner = new Scanner(System.in); // Scanner object

    @SuppressWarnings("ConvertToTryWithResources")
    public static void main(String[] args) {
        int choice;

        do {
            displayMenu();
            choice = getIntegerInput("Enter your choice: ");

            switch (choice) {
                case 1 -> addLibraryItem();
                case 2 -> library.listItems();
                case 3 -> borrowItem();
                case 4 -> System.out.println("Exiting...");
                default -> System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 4);

        scanner.close(); // Close scanner when exiting
    }

    private static void displayMenu() {
        System.out.println("\nLibrary Management System");
        System.out.println("1. Add Item");
        System.out.println("2. List Items");
        System.out.println("3. Borrow Item");
        System.out.println("4. Exit");
    }

    private static int getIntegerInput(String prompt) {
        System.out.print(prompt);
        while (!scanner.hasNextInt()) {
            scanner.nextLine(); // Clear invalid input
            System.out.print("Invalid input. Please enter a number: ");
        }
        return scanner.nextInt();
    }

    private static void addLibraryItem() {
        System.out.println("Add a new item:");
        int type = getIntegerInput("1. Book\n2. Magazine: ");

        switch (type) {
            case 1 ->                 {
                    String title = getStringInput("Enter book title: ");
                    String author = getStringInput("Enter author name: ");
                    String isbn = getStringInput("Enter ISBN: ");
                    library.addItem(new Book(title, author, isbn));
                }
            case 2 ->                 {
                    String title = getStringInput("Enter magazine title: ");
                    String issueDate = getStringInput("Enter issue date (YYYY-MM-DD): ");
                    library.addItem(new Magazine( type, title, issueDate));
                }
            default -> System.out.println("Invalid choice.");
        }
    }

    private static String getStringInput(String prompt) {
        System.out.print(prompt);
        scanner.nextLine(); // Consume any leftover newline character
        return scanner.nextLine();
    }

    private static void borrowItem() {
        String title = getStringInput("Enter the title of the item to borrow: ");
        LibraryItem item = library.findItemByTitle(title);

        if (item != null && item instanceof Borrowable) {
            ((Borrowable) item).borrow();
            System.out.println("Item borrowed successfully!");
        } else if (item == null) {
            System.out.println("Item not found.");
        } else {
            System.out.println("This item cannot be borrowed.");
        }
    }
}