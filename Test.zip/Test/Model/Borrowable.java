

public interface Borrowable {
    void borrow();
    void returnItem();
}


