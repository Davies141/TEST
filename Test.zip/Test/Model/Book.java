

public class Book extends LibraryItem implements Borrowable {
    private static int id;
    private String author;
    private String isbn;
    private boolean isBorrowed;

    public Book(String title, String author, String isbn) {
        super(id, title);
        this.author = author;
        this.isbn = isbn;
        this.isBorrowed = false;
    }

    @Override
    public String getDetails() {
        return "Author: " + author + ", ISBN: " + isbn;
    }

    @Override
    public boolean isAvailable() {
        return !isBorrowed;
    }

    @Override
    public void borrow() {
        if (isAvailable()) {
            isBorrowed = true;
            System.out.println("Book borrowed successfully.");
        } else {
            System.out.println("Book is already borrowed.");
        }
    }

    @Override
    public void returnItem() {
        if (!isAvailable()) {
            isBorrowed = false;
            System.out.println("Book returned successfully.");
        } else {
            System.out.println("Book is already available.");
        }
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }
    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }
}


