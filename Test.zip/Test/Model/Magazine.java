
public class Magazine extends LibraryItem {
    private String issueDate;

    public Magazine(int id, String title, String issueDate) {
        super(id, title);
        this.issueDate = issueDate;
    }

    @Override
    public String getDetails() {
        return "Issue Date: " + issueDate;
    }

    @Override
    public boolean isAvailable() {
        return true; // Magazines are always available
    }

    public String getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(String issueDate) {
        this.issueDate = issueDate;
    }
}


